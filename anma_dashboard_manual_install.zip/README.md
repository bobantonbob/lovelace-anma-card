# ANMA Dashboard Card 0.7.5

Copy anma-card.js to /config/www/anma/anma-card.js.
Update the existing Home Assistant JavaScript module resource to /local/anma/anma-card.js?v=0.7.5.
Keep only one ANMA resource, then refresh Home Assistant. Existing dashboard layouts and entity bindings are preserved.

This build includes Energy Station: 10 PV fields, 5 batteries, GEN/AUX roles, optional load groups and responsive light/dark layouts.
Use the included YAML examples or import the layout exported from the ANMA dashboard editor.
